﻿using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using Grpc.Net.Client;
using gRPCDemoClient;
using System;
using System.Threading.Tasks;

namespace gRPCClient
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            //Create Channel
            GrpcChannel channel= GrpcChannel.ForAddress("https://localhost:5001");

            /// Create Client for our service
            //var client = new Greeter.GreeterClient(channel);

            //HelloRequest request = new HelloRequest() { Name = "Prakash" };
            //HelloReply response = client.SayHello (request);

            //Console.WriteLine(response.Message);

            var client = new StockServer.StockServerClient(channel);

            //****************
            ValueByNameRequest request = new ValueByNameRequest() { StockName = "Wipro" };
            StockResult response = client.GetValueByName(request);

            Console.WriteLine(String.Format("Stock {0} value is {1}" , 
                                                response.Name, response.Value));


            //****************
            var reply = client.GetAllStockValues(new Empty());

            foreach (var stResult in reply.Result)
            {
                Console.WriteLine(String.Format("Stock {0} value is {1}",
                                               stResult.Name, stResult.Value));
            }


            // **********************
            ValueByNameRequest steamRequest = new ValueByNameRequest() { StockName = "TCS" };
            var response1 = client.GetStockValue(steamRequest);

            while (await response1.ResponseStream.MoveNext())
            {
                Console.WriteLine(String.Format("Stock {0} value is {1} on {2}",
                    response1.ResponseStream.Current.Name,
                    response1.ResponseStream.Current.Value,
                    DateTime.Now.ToString()
                    ));
            }

            Console.WriteLine("gRPC call Compelted");

            Console.ReadLine(); 
        }
    }
}
